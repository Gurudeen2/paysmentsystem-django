from django.contrib import admin
from .models import Goods

# Register your models here.

admin.site.register(Goods)
